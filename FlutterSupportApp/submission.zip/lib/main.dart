import 'package:english_words/english_words.dart'; 
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; 
import 'dart:async'; 




void main() {
  WidgetsFlutterBinding.ensureInitialized();
  return runApp(App());
}

class App extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return  Scaffold(
            body: Center(
              child: Text(snapshot.error.toString(),
                textDirection: TextDirection.ltr,)
                )
                );
        }
          if (snapshot.connectionState == ConnectionState.done){
            return MyApp();
          }
          return Center(child: CircularProgressIndicator());
        },
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}): super(key: key);

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      title: 'Startup Name Generator',
      theme: ThemeData(  
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.black,
        ),
      ),
      themeMode: ThemeMode.light,
      home: const RandomWords(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final FirebaseAuth _auth = FirebaseAuth.instance;    
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading=false;


  void _signup() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await _auth.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('There was an error in signing up.'),
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _login() async {

    setState(() {
      _isLoading = true;
    });

    try{
      await _auth.signInWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );
      Navigator.of(context).pop();
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text( 'There was an error loggin.')
          ),
        );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login Screen'),
        leading: IconButton(
        icon: Icon(Icons.arrow_back),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Email',
              ),
            ),
            const SizedBox(height: 16.0),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
              ),
            ),
            const SizedBox(height: 32.0),
            _isLoading
                ? const CircularProgressIndicator()
                :
            ElevatedButton(
              onPressed: _isLoading ? null : _login,
              child: const Text('Login'),
            ),
            ElevatedButton(
              child: const Text('Sign Up'),
              onPressed: _isLoading ? null :_signup,
            )
          ],
        ),
      ),
    );
  }
}

class RandomWords extends StatefulWidget {
  const RandomWords({Key? key}) : super(key: key);

  @override
  State<RandomWords> createState() => _RandomWordsState();
}

class _RandomWordsState extends State<RandomWords> {

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final List<WordPair> _allWords = <WordPair>[];
  final Set<WordPair> _saved = {};
  final TextStyle _biggerFont = const TextStyle(fontSize: 18);

  late StreamSubscription<User?> _authSubscription;

  @override
  void initState(){
    super.initState();
    _authSubscription = _auth.authStateChanges().listen((User? user) {
      if(user != null){
       _fetchUserFavorites(user.uid);
      }else{
        setState((){
          _saved.clear();
        });
        }
    });
  }

  @override
  void dispose(){
    _authSubscription.cancel();
    super.dispose();
  }

  void _fetchUserFavorites(String userId){
    _firestore.collection('users').doc(userId).get().then((snapshot){
      if(snapshot.exists){
        setState(() {
          Set<WordPair> userFavorites = (snapshot.data()?['favorites'] as List<dynamic>).map((item) => WordPair(item['first'], item['second'])).toSet();
          _saved.addAll(userFavorites);
        });
      }
    });
  }

  void _toggleSaved(WordPair pair){
    final alreadySaved = _saved.contains(pair);
    setState(() {
      if(alreadySaved){
        _saved.remove(pair);
        if(_auth.currentUser != null){
          _updateUserFavorites(_auth.currentUser!.uid);
        }
      }else{
        _saved.add(pair);
        if(_auth.currentUser != null){
          _updateUserFavorites(_auth.currentUser!.uid);
        }
      }
    });
  }

  void _updateUserFavorites(String userId){
    _firestore.collection('users').doc(userId).set({
      'favorites': _saved.map((pair) => {'first': pair.first, 'second': pair.second}).toList(),
    });
  }


  void _pushSaved() {
  Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (context) {
        final tiles = _saved.map(
          (pair) {
            return Dismissible(
              key: Key(pair.asPascalCase),
              background: Container(
                color: Colors.red,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Icon(Icons.delete, color: Colors.white),
                    SizedBox(width: 8.0),
                    Text('Delete Suggestion', style: TextStyle(color: Colors.white)),
                  ],
                ),
              ),
              confirmDismiss: (direction) async {
                bool confirmDelete = await showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text("Confirm"),
                      content: const Text("Are you sure you wish to delete this item?"),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(true),
                          child: const Text("DELETE")
                        ),
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(false),
                          child: const Text("CANCEL"),
                        ),
                      ],
                    );
                  },
                );
                if(confirmDelete){
                  setState(() {
                    _saved.remove(pair);
                    if(_auth.currentUser != null){
                      _updateUserFavorites(_auth.currentUser!.uid);
                    }
                  });
                }
                return confirmDelete;
              },
              child: ListTile(
                title: Text(
                  pair.asPascalCase,
                  style: _biggerFont,
                ),
              ),
            );
          },
        );
        final divided = tiles.isNotEmpty
            ? ListTile.divideTiles(
                context: context,
                tiles: tiles,
              ).toList()
            : <Widget>[];

        return Scaffold(
          appBar: AppBar(
            title: const Text('Saved Suggestions'),
          ),
          body: ListView(children: divided),
        );
      },
    ),
  );
}

    void _loginAction() {
      Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (context) {
          return LoginScreen();  
        },
      ),
    );
    }


    void _logout() async {
      await _auth.signOut();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content:Text('You have been successfully logged out'),
          ),
      );
    }

    Widget _buildSuggestions(){
      return ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemBuilder: (context, i) {
          if (i.isOdd) return const Divider();

          final index = i ~/ 2;
          if(index>= _allWords.length){
            _allWords.addAll(generateWordPairs().take(10));
          }
          return _buildRow(_allWords[index]);
          },
  );
}

  Widget _buildRow(WordPair pair) {
    final alreadySaved = _saved.contains(pair);
    return ListTile(
      title: Text(
        pair.asPascalCase,
        style: _biggerFont,
      ),
      trailing: IconButton(
        icon: Icon(
          alreadySaved ? Icons.star : Icons.star_border,
          color: alreadySaved ? Colors.yellow : null,
          semanticLabel: alreadySaved ? 'Remove from saved' : 'Save',
        ),
      onPressed: () {
        _toggleSaved(pair);
      },
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(   
      appBar: AppBar(  
        title: const Text('Startup Name Generator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            onPressed: _pushSaved,
            tooltip: 'Saved Suggestions',
          ),
          StreamBuilder<User?>(
            stream: _auth.authStateChanges(),
            builder: (context, snapshot){
              if(snapshot.hasData){
                return IconButton(
                  icon: Icon(Icons.exit_to_app),
                  onPressed: _logout,
                  tooltip: 'Logout',
                );
              
            } else{
              return IconButton(
                icon: Icon(Icons.login),
                onPressed: _loginAction,
                tooltip: 'Login',
              );
            }
            },
            ),
        ],
      ),
      body: _buildSuggestions(),
    );
}
}