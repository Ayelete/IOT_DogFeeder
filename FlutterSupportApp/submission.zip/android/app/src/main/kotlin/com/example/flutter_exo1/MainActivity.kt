package com.example.flutter_exo1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
